#ifndef LIST_H
#define LIST_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdatomic.h>
#include <stdbool.h>

typedef struct linked_list {
    atomic_int input;
    struct linked_list* _Atomic next;
} l_l;

static inline l_l* ll_create(void) {
    l_l* head = NULL;
    head = (l_l*)malloc(sizeof(l_l));
    if (head == NULL) {
        return NULL;
    }

    atomic_init(&head->input, 0);
    atomic_init(&head->next, NULL);

    return head;
}

static inline int ll_length(l_l* ll) {
    l_l* tempA = atomic_load(&ll->next);
    int count = 0;

    while (tempA != NULL) {
        count += 1;
        tempA = atomic_load(&tempA->next);
    }
    return count;
}

static inline void ll_destroy(l_l* ll) {
    l_l* current = atomic_load(&ll->next);
    l_l* next;

    while (current != NULL) {
        next = atomic_load(&current->next);
        free(current);
        current = next;
    }

    free(ll);
}

static inline void ll_add(l_l* ll, int value) {
    l_l* new_node;
    new_node = (l_l*)malloc(sizeof(l_l));
    atomic_init(&new_node->input, value);

    l_l* old_head;

    do {
        old_head = atomic_load(&ll->next);
        atomic_store(&new_node->next, old_head);
    } while (!atomic_compare_exchange_weak(&ll->next, &old_head, new_node));
}

static inline bool ll_remove_first(l_l* ll) {
    l_l* head = atomic_load(&ll->next);

    if (head == NULL) {
        return false;
    }

    l_l* new_head = atomic_load(&head->next);

    if (atomic_compare_exchange_weak(&ll->next, &head, new_head)) {
        free(head);
        return true;
    }

    return false;
}

static inline int ll_contains(l_l* ll, int value) {
    l_l* tempA = atomic_load(&ll->next);
    int loc = 1;

    while (tempA != NULL) {
        if (atomic_load(&tempA->input) == value) {
            return loc;
        }
        tempA = atomic_load(&tempA->next);
        loc += 1;
    }

    return 0;
}

static inline int ll_print(l_l* ll) {
    l_l* tempA = atomic_load(&ll->next);
    bool not_first = false;
    printf("[ ");

    while (tempA != NULL) {
        if (not_first) {
            printf(", ");
        }
        printf("%d", atomic_load(&tempA->input));
        tempA = atomic_load(&tempA->next);
        not_first = true;
    }

    printf(" ]\n");
    return 0;
}
#endif