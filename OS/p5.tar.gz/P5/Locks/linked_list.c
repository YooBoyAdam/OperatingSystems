#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <stdbool.h>
#include "list.h"

#define THREADS_COUNT 3
#define NUM_OPERATIONS 75

pthread_mutex_t lock;

struct thread_args {
    struct linked_list *ll;
    int id;
};

void *insert_thread(void *args) {
    struct thread_args *t_args = (struct thread_args *) args;
    for (int i = 0; i < NUM_OPERATIONS; i++) {
        ll_add(t_args->ll, i + t_args->id * NUM_OPERATIONS);
    }
    pthread_exit(NULL);
}

void *delete_thread(void *args) {
    struct thread_args *t_args = (struct thread_args *) args;
    for (int i = 0; i < NUM_OPERATIONS; i++) {
        ll_remove_first(t_args->ll);
    }
    pthread_exit(NULL);
}

void *lookup_thread(void *args) {
    struct thread_args *t_args = (struct thread_args *) args;
    for (int i = 0; i < NUM_OPERATIONS; i++) {
        int loc = ll_contains(t_args->ll, i + t_args->id * NUM_OPERATIONS);
        if (loc > 0) {
            printf("\t Found: %d \n\t Location: %d \n\t Thread: %d\n\n", i + t_args->id * NUM_OPERATIONS, loc,  t_args->id);
        }
    }
    pthread_exit(NULL);
}


int main() {
    struct linked_list *ll = ll_create();
    struct linked_list *ll_copy = ll_create();

    printf("\nEmpty Linked List: ");
    ll_print(ll);

    pthread_t threads[THREADS_COUNT];
    struct thread_args t_args[THREADS_COUNT];

    pthread_mutex_init(&lock, NULL);

    for (int i = 0; i < THREADS_COUNT; i++) {
        t_args[i].ll = ll;
        t_args[i].id = i;
        pthread_create(&threads[i], NULL, insert_thread, (void *) &t_args[i]);
    }

    for (int i = 0; i < THREADS_COUNT; i++) {
        pthread_join(threads[i], NULL);
    }

    printf("\n\nPopulated Linked List: ");
    ll_print(ll);

    //populating ll_copy

    l_l *tempA = ll->next;
    l_l *tempB = ll_copy;
    while (tempA != NULL) {
        ll_add(tempB, tempA->input);
        tempA = tempA->next;
        tempB = tempB->next;
    }

    //checking if same
    int error = 0;
    l_l *temp_ll = ll;
    l_l *temp_copy = ll_copy;
    while (temp_ll->next != NULL && temp_copy->next != NULL) {
        temp_ll = temp_ll->next;
        temp_copy = temp_copy->next;
        if (temp_ll->input != temp_copy->input) {
            error += 1;
        }
    }
    if (temp_ll->next != temp_copy->next) {
        error += 1;
    }
    if(error > 0){
        printf("----------Error with populating copy linked list!----------");
    }

    printf("\n\nBegin lookups\n\n");

    for (int i = 0; i < THREADS_COUNT; i++) {
        pthread_create(&threads[i], NULL, lookup_thread, (void *) &t_args[i]);
    }

    for (int i = 0; i < THREADS_COUNT; i++) {
        pthread_join(threads[i], NULL);
    }

    //checking if ll is still the same as ll_copy
    error = 0;
    temp_ll = ll;
    temp_copy = ll_copy;
    while (temp_ll->next != NULL && temp_copy->next != NULL) {
        temp_ll = temp_ll->next;
        temp_copy = temp_copy->next;
        if (temp_ll->input != temp_copy->input) {
            error += 1;
        }
    }
    if (temp_ll->next != temp_copy->next) {
        error += 1;
    }
    if(error > 0){
        printf("\n----------Error: List was edited during lookup---------- \n");
    } 
    else{
        printf("\nList was not edidted during lookup! \n");
    }

    // Verify that all inserted data are present
    for (int i = 0; i < THREADS_COUNT * NUM_OPERATIONS; i++) {
        if (!ll_contains(ll, i)) {
            printf("----------Error: value %d not found in list---------- \n", i);
        }
    }

    //Deleting everything

    printf("\nDeleting...\n");
    for (int i = 0; i < THREADS_COUNT; i++) {
        pthread_create(&threads[i], NULL, delete_thread, (void *) &t_args[i]);
    }

    for (int i = 0; i < THREADS_COUNT; i++) {
        pthread_join(threads[i], NULL);
    }

    //verifying deleted
    if (ll->next == NULL) {
        printf("The linked list is empty.\n");
    }
    else{
        printf("----------Error: Linked list is not empty----------\n");
    }

    pthread_mutex_destroy(&lock);


    ll_destroy(ll);

    return 0;
}       



