#ifndef LIST_H
#define LIST_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "stdbool.h"
#include <pthread.h>

typedef struct linked_list{
    int input;
    struct linked_list *next;
    pthread_mutex_t lock;
} l_l;

static inline struct linked_list * ll_create(void)
{
    l_l *head = NULL;
    head = (l_l *) malloc(sizeof(l_l));
    if(head == NULL){
        return NULL;
    }

    head->next = NULL;
    pthread_mutex_init(&head->lock, NULL);

    return head;
}

static inline int ll_length(struct linked_list *ll)
{
    l_l *tempA = ll;
    int count = 0;

    while(tempA->next != NULL){
        count += 1;
        tempA = tempA->next;
    }
    return count;
}

static inline int ll_destroy(struct linked_list *ll)
{
    int len = ll_length(ll);
    if(len > 0){
        //list not empty, could not destroy
        return 0;
    }

    struct linked_list* current = ll;
    struct linked_list *next;
    while(current != NULL){
        next = current->next;
        pthread_mutex_destroy(&current->lock);
        free(current);
        current = next;
    }
    ll = NULL;

    return 1;
}

static inline void ll_add(struct linked_list *ll, int value)
{
    l_l *new_node;
    new_node = (l_l *) malloc(sizeof(l_l));
    new_node->input = value;

    pthread_mutex_lock(&ll->lock);
    new_node->next = ll->next;
    ll->next = new_node;
    pthread_mutex_unlock(&ll->lock);
}


static inline bool ll_remove_first(struct linked_list *ll)
{
    int len = ll_length(ll);
    //if list empty, return false
    if(len == 0){
        return false;
    }
    //else remove first node, return true
    l_l *new_head = NULL;
    new_head = ll->next;
    ll->input = new_head->input;

    pthread_mutex_lock(&new_head->lock);
    ll->next = new_head->next;
    pthread_mutex_unlock(&new_head->lock);
    free(new_head);

    return true;
}

static inline int ll_contains(struct linked_list *ll, int value)
{
    l_l * tempA = ll;
    int loc = 1;
    int len = ll_length(ll);
    int count = 0;
    while (count < len) {
        if(tempA->input == value)
            return loc;
        tempA = tempA->next;
        loc += 1;
        count += 1;
    }
    return 0;
}

static inline int ll_print(struct linked_list *ll){
    l_l * tempA = ll;
    int len = ll_length(ll);
    int count = 0;
    bool not_first = false;
    printf("[ ");
    while (count < len) {
        if(not_first){
            printf(", ");
        }
        printf("%d", tempA->input);
        tempA = tempA->next;
        not_first = true;
        count += 1;
    }
    printf(" ]\n");
    return 0;
}

#endif

